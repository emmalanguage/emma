var data = {};
data.nodes = ["asldkjddsddsd","sadksjf kj",2,"sldkfj lksdjf kljsd lkfj lskjdfl kj","hallo das ist ein langer text langer langer langer","dsf lkjdsd lkfjsdlk fjslkdjflksd jlkfj sl","adslkjal ksjdlkajslk djlks jdlka jlkdj alkj dlkajslkdaljd lkj",7,8,9,10,11];
data.edges = [
    /*
    [12,1],
    [13,1],
    [14,1],
    [15,1],
    */
    [0,1],
    [1,3],
    [1,4],
    [1,7],
    [1,10],
    [2,5],
    [2,6],
    [2,11],
    [3,7],
    [4,7],
    [5,8],
    [6,7],
    [6,8],
    [7,9],
    [8,9],
    [9,10],
    [9,11],
    [9,0]
];

var Node = function(label){
    var node = {
        id: null,
        label: label,
        type: null,
        parents: [],
        children: [],
        placeholderPaths: [],
        width: 10,
        height: 10,
        offsetX: 0,
        x: null,
        y: null,
        padding: [5,5,5,5],
        shape: null,

        draw: function() {
            /*
            if (this.type == "placeholder") {
                var parentNode = this.getParents()[0];
                while (parentNode.type == "placeholder") {
                    parentNode = parentNode.getParents()[0];
                }

                this.setLabel(parentNode.id);
                this.text.position = [this.x + this.padding[3] + this.text.bounds.width/2, this.y + this.padding[0] + this.text.bounds.height/2];
            } else {

            }
            */

            this.text.position = [this.x, this.y];

            if (this.shape == null) {
                this.shape = new planCanvas.Shape.Rectangle({
                    point: new planCanvas.Point(this.x - this.width/2, this.y - this.height/2),
                    size: new planCanvas.Size(this.width, this.height),
                    strokeColor: strokeColor,
                    strokeWidth: strokeWidth,
                    fillColor: "black"
                });
                this.text.bringToFront();
            } else {
                //TODO: implement position update
                console.error("position update not implemented");
            }
        },

        setLabel: function(label) {
            if (this.text != null) {
                label = label+"";
                if (label.length <= 1) {
                    var maxLength = 1;
                } else {
                    var maxLength = Math.ceil(Math.sqrt(label.length) * 2);
                }
                this.text.wordwrap(label, maxLength);
                this.text.justification = "center";

                this.width = this.text.bounds.width + this.padding[1] + this.padding[3];
                this.height = this.text.bounds.height + this.padding[0] + this.padding[2];
            }
        },

        setType: function(type) {
            this.type = type;
            if (this.type == "placeholder") {
                //this.text.remove();
            }
        },

        addChild: function(node) {
            var edge = Edge(this, node);
            edges.push(edge);
            this.children.push(edge);
            node.parents.push(edge);
        },

        getChildren: function() {
            var childNodes = [];
            this.children.forEach(function(child){
                childNodes.push(child.targetNode);
            });
            return childNodes;
        },

        addParent: function(node) {
            var edge = Edge(node, this);
            edges.push(edge);
            this.parents.push(edge);
            node.children.push(edge);
        },

        getParents: function() {
            var parentNodes = [];
            this.parents.forEach(function(parent){
                parentNodes.push(parent.sourceNode);
            });
            return parentNodes;
        },

        setPosition: function(x,y) {
            this.x = x;
            this.y = y;
        },
    };

    //init
    node.text = new planCanvas.PointText({
        position: [node.x, node.y],
        content: "",
        fillColor: strokeColor,
        fontFamily: font,
        fontSize: fontSize
    });

    //node.text.remove();

    node.setLabel(node.label);

    node.width = node.text.bounds.width + node.padding[1] + node.padding[3];
    node.height = node.text.bounds.height + node.padding[0] + node.padding[2];

    return node;
}

var Edge = function(obj) {
    var edge = {
        points: obj.points,
        draw: function() {
            var segments = [];

            this.points.forEach(function(point){
                segments.push([point.x, point.y]);
            });

            var path = arc({
                segments: segments,
                color: strokeColor,
                fillArrows: true,
            });

            path = roundPath(path, 5);
        }
    };
    return edge;
}

var nodes = [];
var edges = [];

function initNodes() {
    var g = new dagre.graphlib.Graph();
    g.setGraph({});
    g.setDefaultEdgeLabel(function() { return {}; });

    for (var i = 0; i < data.nodes.length; i++) {
        g.setNode(i, new Node(data.nodes[i]));
    }

    data.edges.forEach(function(edge){
        g.setEdge(edge[0], edge[1]);
    });

    dagre.layout(g);

    g.edges().forEach(function(e) {
        var edge = new Edge(g.edge(e));
        edge.draw();
        edges.push(edge);
    });

    g.nodes().forEach(function(v) {
        var node = g.node(v);
        node.draw();
        nodes.push(node);
    });
}