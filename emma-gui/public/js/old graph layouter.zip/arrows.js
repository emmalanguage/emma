paper.Shape.ArrowLine = function (object) {
    var sx = 0,
        sy = 0,
        ex = 0,
        ey = 0,
        startArrow = null,
        endArrow = 'arrow',
        color = 'black',
        strokeWidth = 1,
        dashArray = null,
        fillArrows = false,
        text = null;

    if (object.segments == null || object.segments.length == 0) {
        console.error("No segments to draw.", object);
        return;
    }

    var segmentsCount = object.segments.length;

    if (object.color != null)
        color = object.color;

    if (object.double != null)
        double = object.double;

    if (object.dashArray != null)
        dashArray = object.dashArray;

    if (object.strokeWidth != null)
        strokeWidth = object.strokeWidth;

    if (object.fillArrows != null)
        fillArrows = object.fillArrows;

    if (object.startArrow != null)
        startArrow = object.startArrow;

    if (object.endArrow != null)
        endArrow = object.endArrow;

    if (object.text != null)
        text = object.text;

    function calcArrow(px0, py0, px, py) {
        var points = [];
        var l = Math.sqrt(Math.pow((px - px0), 2) + Math.pow((py - py0), 2)) * 1.5;
        points[0] = (px - ((px - px0) * Math.cos(0.5) - (py - py0) * Math.sin(0.5)) * 10 / l);
        points[1] = (py - ((py - py0) * Math.cos(0.5) + (px - px0) * Math.sin(0.5)) * 10 / l);
        points[2] = (px - ((px - px0) * Math.cos(0.5) + (py - py0) * Math.sin(0.5)) * 10 / l);
        points[3] = (py - ((py - py0) * Math.cos(0.5) - (px - px0) * Math.sin(0.5)) * 10 / l);
        return points;
    }


    var length = Math.sqrt(Math.pow((ex - sx), 2) + Math.pow((ey - sy), 2));

    if (text != null) {
        var endPoint = new paper.Point(sx + length, sy);
    } else {
        var endPoint = new paper.Point(ex, ey);
    }

    var line = new paper.Path({
        segments: object.segments,
        strokeWidth: strokeWidth,
        dashArray: dashArray,
        strokeColor: color
    });

    if (endArrow != null) {
        sx = object.segments[segmentsCount-2][0];
        sy = object.segments[segmentsCount-2][1];

        ex = object.segments[segmentsCount-1][0];
        ey = object.segments[segmentsCount-1][1];

        if (endArrow == 'arrow') {
            var endPoints = calcArrow(sx, sy, ex, ey);

            var e0 = endPoints[0],
                e1 = endPoints[1],
                e2 = endPoints[2],
                e3 = endPoints[3];

            new paper.Path({
                segments: [
                    new paper.Point(e0, e1),
                    new paper.Point(ex, ey),
                    new paper.Point(e2, e3)
                ],
                strokeWidth: strokeWidth,
                strokeColor: color,
                fillColor: (fillArrows) ? color : null
            });

        } else if (endArrow == 'circle') {
            new paper.Shape.Circle({
                center: new paper.Point(ex, ey),
                radius: 10,
                strokeColor: color,
                strokeWidth: strokeWidth,
                fillColor: (fillArrows) ? color : null
            });
        }
    }

    if (startArrow != null) {
        sx = object.segments[0][0];
        sy = object.segments[0][1];

        ex = object.segments[1][0];
        ey = object.segments[1][1];

        if (startArrow == 'arrow') {
            var startPoints = calcArrow(ex, ey, sx, sy);
            var s0 = startPoints[0],
                s1 = startPoints[1],
                s2 = startPoints[2],
                s3 = startPoints[3];

            new paper.Path({
                segments: [
                    new paper.Point(s0, s1),
                    new paper.Point(sx, sy),
                    new paper.Point(s2, s3)
                ],
                strokeWidth: strokeWidth,
                strokeColor: color,
                fillColor: (fillArrows) ? color : null
            });
        } else if (startArrow == 'circle') {
            new paper.Shape.Circle({
                center: new paper.Point(sx, sy),
                radius: 10,
                strokeColor: color,
                strokeWidth: strokeWidth,
                fillColor: (fillArrows) ? color : null
            });
        }
    }

    if (text != null) {
        var pointText = new paper.PointText({
            content: text,
            fillColor: color
        });

        var textOffset = pointText.bounds.height / 2;

        if (ex < sx) {
            textOffset *= -1;
        }

        var middlePoint = new paper.Point((sx+sx+length)/2, sy - textOffset);
        pointText.position = middlePoint;

        var group = new paper.Group([line, pointText]);
        var angle = Math.atan((sy-ey) / (sx-ex)) * (180/Math.PI);

        if (ex < sx) {
            angle += 180;
            pointText.rotate(180);
        }

        group.rotate(angle, new paper.Point(sx, sy));
    }

};


function arc(obj) {
	var segments = obj.segments,
	    path = new paper.Path(),
	    startArrow = null,
        endArrow = 'arrow',
        strokeWidth = 1,
        color = null,
        text = null,
        dashArray = null,
        fillArrows = false;

    if (obj.segments == null || obj.segments.length == 0) {
        console.error("No segments to draw.", obj);
        return;
    }

    if (obj.color != null)
        color = obj.color;

    if (obj.dashArray != null)
        dashArray = obj.dashArray;

    if (obj.strokeWidth != null)
        strokeWidth = obj.strokeWidth;

    if (obj.fillArrows != null)
        fillArrows = obj.fillArrows;

    if (obj.startArrow != null)
        startArrow = obj.startArrow;

    if (obj.endArrow != null)
        endArrow = obj.endArrow;

    if (obj.text != null)
        text = obj.text;

    if (color != null)
	    path.strokeColor = color;

    if (strokeWidth != null)
	    path.strokeWidth = strokeWidth;

	//first point
	path.add(new paper.Point(segments[0][0], segments[0][1]));

    for (var i = 1; i < segments.length; i++) {
        var centerPoint = new paper.Point(segments[i-1][0] - 10, segments[i-1][1] + 10);
        //path.quadraticCurveTo(centerPoint, new paper.Point(segments[i][0], segments[i][1]));
        path.lineTo(new paper.Point(segments[i][0], segments[i][1]));
    }

    if (endArrow != null) {
        sx = segments[segments.length-2][0];
        sy = segments[segments.length-2][1];

        ex = segments[segments.length-1][0];
        ey = segments[segments.length-1][1];

        if (endArrow == 'arrow') {
            var endPoints = calcArrow(sx, sy, ex, ey);

            var e0 = endPoints[0],
                e1 = endPoints[1],
                e2 = endPoints[2],
                e3 = endPoints[3];

            new paper.Path({
                segments: [
                    new paper.Point(e0, e1),
                    new paper.Point(ex, ey),
                    new paper.Point(e2, e3)
                ],
                strokeWidth: strokeWidth,
                strokeColor: color,
                fillColor: (fillArrows) ? color : null
            });

        } else if (endArrow == 'circle') {
            new paper.Shape.Circle({
                center: new paper.Point(ex, ey),
                radius: 10,
                strokeColor: color,
                strokeWidth: strokeWidth,
                fillColor: (fillArrows) ? color : null
            });
        }
    }

    if (startArrow != null) {
        sx = segments[0][0];
        sy = segments[0][1];

        ex = segments[1][0];
        ey = segments[1][1];

        if (startArrow == 'arrow') {
            var startPoints = calcArrow(ex, ey, sx, sy);
            var s0 = startPoints[0],
                s1 = startPoints[1],
                s2 = startPoints[2],
                s3 = startPoints[3];

            new paper.Path({
                segments: [
                    new paper.Point(s0, s1),
                    new paper.Point(sx, sy),
                    new paper.Point(s2, s3)
                ],
                strokeWidth: strokeWidth,
                strokeColor: color,
                fillColor: (fillArrows) ? color : null
            });
        } else if (startArrow == 'circle') {
            new paper.Shape.Circle({
                center: new paper.Point(sx, sy),
                radius: 10,
                strokeColor: color,
                strokeWidth: strokeWidth,
                fillColor: (fillArrows) ? color : null
            });
        }
    }

	return path;
}

function calcArrow(px0, py0, px, py) {
    var points = [];
    var l = Math.sqrt(Math.pow((px - px0), 2) + Math.pow((py - py0), 2)) * 1.5;
    points[0] = (px - ((px - px0) * Math.cos(0.5) - (py - py0) * Math.sin(0.5)) * 10 / l);
    points[1] = (py - ((py - py0) * Math.cos(0.5) + (px - px0) * Math.sin(0.5)) * 10 / l);
    points[2] = (px - ((px - px0) * Math.cos(0.5) + (py - py0) * Math.sin(0.5)) * 10 / l);
    points[3] = (py - ((py - py0) * Math.cos(0.5) - (px - px0) * Math.sin(0.5)) * 10 / l);
    return points;
}

function roundPath(path,radius) {

    var segments = path.segments.slice(0);
    path.segments = [];
    for(var i = 0, l = segments.length; i < l; i++) {
        var curPoint = segments[i].point;
        var nextPoint = segments[i + 1 == l ? 0 : i + 1].point;
        var prevPoint = segments[i - 1 < 0 ? segments.length - 1 : i - 1].point;
        var nextDelta = minus(curPoint, nextPoint);
        var prevDelta = minus(curPoint, prevPoint);
        nextDelta.length = radius;
        prevDelta.length = radius;

        new paper.Point(1,1);
        if (i > 0 && i < segments.length - 1) {
            path.add({
                point: minus(curPoint, prevDelta),
                handleOut: divide(prevDelta, 2)
            });
            path.add({
                point: minus(curPoint, nextDelta),
                handleIn: divide(nextDelta, 2)
            });
        } else {
            path.add({
                point: curPoint,
            });
        }

    }
    //path.closed = true;
    return path;
}

function minus(p1, p2) {
    return new paper.Point(p1.x - p2.x, p1.y - p2.y);
}

function divide(p1, num) {
    return new paper.Point(p1.x / num, p1.y / num);
}