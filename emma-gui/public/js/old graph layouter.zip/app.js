var codeCanvas = null,
    planCanvas = null;

$(window).resize(resizeContainers);
resizeContainers();

function clearPage(){
    var code = $('#code-container code');
    code.html("");
    code.width("auto");
    code.parent().width("auto");

    if (planCanvas != null) {
        planCanvas.project.activeLayer.removeChildren();
        planCanvas.view.draw();
        planCanvas = null;
    }

    if (codeCanvas != null) {
        codeCanvas.project.activeLayer.removeChildren();
        codeCanvas.view.draw();
        codeCanvas = null;
    }
}

function loadCode(name) {
    $.ajax({
        method: "GET",
        url: "http://localhost:8080/code/"+name,
        success: function(data) {
            var code = $('#code-container code');
            var codeCanvasElement = $('#code-container canvas');

            code.html(data);
            code.each(function(i, block) {
                hljs.highlightBlock(block);
            });

            var contentWidth = code[0].scrollWidth;
            code.width(contentWidth);
            codeCanvasElement.width(contentWidth);
            codeCanvasElement.height(code.height()+20);
            code.parent().width(contentWidth+20);

            drawPlan();

            drawComprehensionBox(105, 129);
            drawComprehensionBox(177, 323);
        }
    });
}

function setupCodeCanvas() {
    if (codeCanvas == null) {
        codeCanvas = new paper.PaperScope().setup(document.getElementById('code-canvas'));
    }
}

function drawComprehensionBox(begin, end) {
    var margin = 2;
    var highlightColor = 'rgba(255,0,0,0.4)';

    setupCodeCanvas();
    var clientRect = setSelectionRange($('#code-container code')[0], begin, end);
    var rectangle = new codeCanvas.Shape.Rectangle(new codeCanvas.Point(clientRect.left - margin, clientRect.top - margin), clientRect.width + margin, clientRect.height + margin);
    rectangle.fillColor = highlightColor;
    codeCanvas.view.draw();
}

function setSelectionRange(el, start, end) {
    if (document.createRange && window.getSelection) {
        var range = document.createRange();
        range.selectNodeContents(el);
        var textNodes = getTextNodesIn(el);
        var foundStart = false;
        var charCount = 0, endCharCount;

        for (var i = 0, textNode; textNode = textNodes[i++]; ) {
            endCharCount = charCount + textNode.length;
            if (!foundStart && start >= charCount && (start < endCharCount || (start == endCharCount && i <= textNodes.length))) {
                range.setStart(textNode, start - charCount);
                foundStart = true;
            }
            if (foundStart && end <= endCharCount) {
                range.setEnd(textNode, end - charCount);
                break;
            }
            charCount = endCharCount;
        }

        var offset = $(el).parents('#code-container').offset();
        var clientRect = range.getBoundingClientRect();

        var box = {
            top: clientRect.top - offset.top,
            left: range.getClientRects()[0].left - offset.left,
            width: clientRect.width,
            height: clientRect.height
        };

        return box;
    } else if (document.selection && document.body.createTextRange) {
        var textRange = document.body.createTextRange();
        textRange.moveToElementText(el);
        textRange.collapse(true);
        textRange.moveEnd("character", end);
        textRange.moveStart("character", start);
        textRange.select();
    }
}

function getTextNodesIn(node) {
    var textNodes = [];
    if (node.nodeType == 3) {
        textNodes.push(node);
    } else {
        var children = node.childNodes;
        for (var i = 0, len = children.length; i < len; ++i) {
            textNodes.push.apply(textNodes, getTextNodesIn(children[i]));
        }
    }
    return textNodes;
}

function resizeContainers() {
    var newHeight = $("html").height() - $("#code-container").offset().top - 20;
    $("#code-container").css("height", newHeight);
    $(".plan-wrapper").css("height", newHeight);

    $('#plan-canvas').attr("width",$('.code-wrapper').parent().width()-$('#code-container').width() - 25);
    $('#plan-canvas').attr("height",$('#code-container').height() + 14);

    if (planCanvas != null) {
        planCanvas.view.viewSize = [$("#plan-canvas").width(), newHeight];
    }
}