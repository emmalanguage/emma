var IsDrag = false,
    lastX = 0,
    lastY = 0,
    upperZoomLimit = 10,
    lowerZoomLimit = 0.3,
    layers = [],
    layerWidth = [],
    layerHeight = [],
    startHeight = 50,
    maxLayerWidth = 0,
    lines = [],
    edgesInLayerGap = [];


var strokeColor = '#F55B11',
    strokeWidth = 1,
    font = 'Courier New',
    fontSize = 16,
    boxMargin = 5,
    levelSpace = 60,
    nodeSpace = 30,
    outgoingEdgeSpace = 3,
    incomingEdgeSpace = 4;

function drawPlan() {
    setupPlanCanvas();

    initWordWrap();
    initNodes();




    /*
    positioning();
    addNodesToLayers();
    adjustNodeLayerPositions();

    drawNodes();
    //relaxNodes();
    adjustEdgePorts();

    new planCanvas.Shape.Rectangle({
        from: [962, 100],
        to: [972, 110],
        strokeColor: "red",
        strokeWidth: 2
    });

    drawEdges();
    planCanvas.view.draw();
    */
    planCanvas.view.draw();
}

function positioning() {
    nodes.forEach(function(node){
        if (node.parents.length == 0) {
            node.level = 0;
        } else {
            var maxLevel = 0;
            node.getParents().forEach(function(parent){
                if (parent.level != null) {
                    if (parent.level > maxLevel)
                        maxLevel = parent.level;
                }
            });
            node.level = maxLevel + 1;
        }
    });
}

function addNodesToLayers() {
    nodes.forEach(function(node){
        if (node.level != null) {
            if (layers[node.level] == null) {
                layers[node.level] = [];
            }

            node.levelIndex = layers[node.level].push(node) - 1;

            node.getChildren().forEach(function(childNode){
                if (childNode.level > node.level + 1) {

                    var path = [],
                        lastNode = null,
                        placeHolder = null;

                    for (var i = node.level + 1; i < childNode.level; i++) {
                        placeHolder = new Node();
                        placeHolder.setType("placeholder");

                        if (lastNode == null) {
                            placeHolder.addParent(node);
                        } else {
                            placeHolder.addParent(lastNode);
                        }

                        lastNode = placeHolder;

                        if (layers[i] == null)
                            layers[i] = [];

                        layers[i].push(placeHolder);
                        placeHolder.level = i;
                        placeHolder.levelIndex = layers[i].length - 1;
                        path.push(placeHolder);
                    }
                    node.placeholderPaths.push(path);
                    childNode.addParent(placeHolder);
                }
            });
        }
    });
}

function adjustNodeLayerPositions() {
    layers.forEach(function(layer, level){
        var links = getLinksToNextLevel(layer);

        var overlappingIndexes = new Set();

        //find overlapping links
        links.forEach(function(firstLink, firstIndex){
            links.forEach(function(secondLink, secondIndex){
                if (firstIndex != secondIndex && firstLink[0] != secondLink[0]) {
                    if (firstLink[0] < secondLink[0] && secondLink[1] < firstLink[1] ||
                        firstLink[0] > secondLink[0] && secondLink[1] > firstLink[1]) {

                        var smallerIndex = (firstLink[0] < secondLink[0]) ? firstLink[0] : secondLink[0];
                        var biggerIndex = (firstLink[0] > secondLink[0]) ? firstLink[0] : secondLink[0];
                        if (!setHas(overlappingIndexes, [smallerIndex, biggerIndex])) {
                            overlappingIndexes.add([smallerIndex, biggerIndex]);
                        }
                    }
                }
            });
        });

        //swap overlapping nodes
        overlappingIndexes.forEach(function(pair){
            swapNodesInLayer(level, pair);
        });
    });

    nodes.forEach(function(node){
        var hasSpanningLinks = false;
        node.children.forEach(function(edge){
            if (edge.targetNode.level > node.level + 1) {
                hasSpanningLinks = true;
            }
        });
        node.hasSpanningLinks = hasSpanningLinks;
    });
}

function getLinksToNextLevel(layer) {
    var links = [];
    layer.forEach(function(item){
        item.getChildren().forEach(function(child){
            if (item.level + 1 == child.level) {
                links.push([item.levelIndex, child.levelIndex]);
            }
        });

        if (item.placeholderPaths.length > 0) {
            item.placeholderPaths.forEach(function(path){
                var placeHolder = path[0];
                if (item.level + 1 == placeHolder.level) {
                    links.push([item.levelIndex, placeHolder.levelIndex]);
                }
            });
        }
    });
    return links;
}

/**
*   Swaps two nodes in the layer array on the given level. The indexes of the nodes have to be defined in the pair array.
*/
function swapNodesInLayer(level, pair) {
    var swap = layers[level][pair[0]];
    delete layers[level][pair[0]];
    layers[level][pair[0]] = layers[level][pair[1]];
    layers[level][pair[0]].levelIndex = pair[0];
    layers[level][pair[1]] = swap;
    layers[level][pair[1]].levelIndex = pair[1];
}

/**
*   Returns true if the set contains the given pair.
*/
function setHas(set, pair) {
    var has = false;
    set.forEach(function(element){
        if (element[0] == pair[0] && element[1] == pair[1]) {
            has = true;
            return;
        }
    });
    return has;
}

function adjustEdgePorts() {
    adjustOutgoingPorts();
    adjustIncomingPorts();
}

function adjustIncomingPorts() {
    nodes.forEach(function(node){
        var parentEdges = [];

        node.parents.forEach(function(parentEdge){
            if (parentEdge.sourceNode.type != "placeholder")
                parentEdges.push({
                    edge: parentEdge,
                    nextConnection: null
                });
        });

        parentEdges.forEach(function(parentEdge){
            if (parentEdge.edge.sourceNode.level < node.level - 1 ) {
                //search for placeholder node on previous level
                parentEdge.edge.sourceNode.placeholderPaths.forEach(function(path){
                    var lastPlaceholder = path[path.length-1];
                    if (lastPlaceholder.children[0].targetNode == node) {
                        parentEdge.nextConnection = path[path.length-1];
                    }
                });
            } else if (parentEdge.edge.sourceNode.level == node.level - 1) {
                parentEdge.nextConnection = parentEdge.edge.sourceNode;
            } else {
                console.error("Unexpected edge connection.");
            }
        });

        parentEdges.sort(compareIncomingEdges);
        for (var i = 0; i < parentEdges.length; i++) {
            parentEdges[i].edge.targetPort = i;
        }
    });
}

function adjustOutgoingPorts() {
    nodes.forEach(function(node){
        var childEdges = [];

        node.children.forEach(function(childEdge){
            if (childEdge.targetNode.type != "placeholder")
                childEdges.push({
                    edge: childEdge,
                    nextConnection: null
                });
        });

        childEdges.forEach(function(childEdge){
            if (childEdge.edge.targetNode.level > node.level + 1 ) {
                //search for placeholder node on next level
                node.placeholderPaths.forEach(function(path){
                    var lastPlaceholder = path[path.length-1];
                    if (lastPlaceholder.children[0].targetNode == childEdge.edge.targetNode) {
                        childEdge.nextConnection = path[0];
                    }
                });
            } else if (childEdge.edge.targetNode.level == node.level +1) {
                childEdge.nextConnection = childEdge.edge.targetNode;
            } else {
                console.error("Unexpected edge connection.");
            }
        });

        childEdges.sort(compareOutgoingEdges);
        for (var i = 0; i < childEdges.length; i++) {
            childEdges[i].edge.sourcePort = i;
        }
    });
}

function compareOutgoingEdges(a,b) {
    if (a.nextConnection.x < b.nextConnection.x)
        return -1;
    if (a.nextConnection.x > b.nextConnection.x)
        return 1;
    return 0;
}

function compareIncomingEdges(a,b) {
    if (a.nextConnection.x < b.nextConnection.x)
        return -1;
    if (a.nextConnection.x > b.nextConnection.x)
        return 1;
    return 0;
}

function drawNodes() {
    if (layers.length == 0)
        return;

    computeLayerWidths();

    //set node positions
    layers.forEach(function(layer, level){
        var xOffsets = [];

        layerHeight[level] = getLayerHeight(layer);

        var layerOffsetStart = planCanvas.project.view.center.x - maxLayerWidth/2;

        layer.forEach(function(node, levelIndex){
            var freeSpace = maxLayerWidth - layerWidth[level] + (nodeSpace * layer.length);
            var freeChunks = freeSpace / (layer.length + 1);

            if (levelIndex == 0) {
                xOffsets.push(layerOffsetStart + freeChunks);
            } else {
                var offset = 0;
                layer.forEach(function(prevNode, prevIndex){
                    if (prevIndex < levelIndex)
                        offset += prevNode.width + prevNode.offsetX;
                });

                offset += ((levelIndex+1) * freeChunks) + layerOffsetStart;
                xOffsets.push(offset);
            }
        });

        //draw nodes
        layer.forEach(function(node, levelIndex){
            var y = getLayerStartHeight(level);
            var x = xOffsets[levelIndex];

            node.setPosition(x,y);
        });
    });

    for(var i = layers.length - 1; i >= 0; i--) {
        var layer = layers[i];
        layer.forEach(function(node, levelIndex){
            if (node.hasSpanningLinks) {
                //distance to next placeholder
                var xOffsetDiff = 0;
                var distance = Number.MAX_VALUE
                node.placeholderPaths.forEach(function(path){
                    var dis = Math.abs((node.x + node.offsetX) - (path[0].x + path[0].offsetX));
                    if (dis < distance) {
                        distance = dis;
                        xOffsetDiff = (path[0].x + path[0].offsetX) - (node.x + node.offsetX);
                    }
                });

                if (xOffsetDiff > 0) {
                    //move right
                    var freeRightSpace = getRightFreeSpace(node) - boxMargin;
                    if (freeRightSpace > xOffsetDiff) {
                        node.offsetX += xOffsetDiff;
                    } else {
                        xOffsetDiff -= freeRightSpace;
                        node.offsetX += freeRightSpace;
                        moveNode(node, xOffsetDiff);
                    }
                } else {
                    //move left
                    var freeLeftSpace = getLeftFreeSpace(node) - boxMargin;
                    if (freeLeftSpace > Math.abs(xOffsetDiff)) {
                        node.offsetX += xOffsetDiff;
                    } else {
                        //FIXME: maybe not needed
                        //xOffsetDiff += freeLeftSpace;
                        //moveNode(node, xOffsetDiff);
                    }
                }
            }
        });
    }

    layers.forEach(function(layer, level){
        layer.forEach(function(node, levelIndex){
            node.draw();
        });
    });
}

function getLeftFreeSpace(node) {
    if (node.levelIndex == 0) {
        return Number.MAX_VALUE;
    } else {
        var leftSibling = layers[node.level][node.levelIndex-1];
        return node.x - (leftSibling.x + leftSibling.width + nodeSpace);
    }
}

function getRightFreeSpace(node) {
    if (node.levelIndex == layers[node.level].length -1) {
        return Number.MAX_VALUE;
    } else {
        var rightSibling = layers[node.level][node.levelIndex+1];
        return rightSibling.x - (node.x + node.width + nodeSpace);
    }
}

function moveNode(node, offset) {
    if (offset > 0) {
        for (var i = node.levelIndex; i < layers[node.level].length; i++) {
            var sibling = layers[node.level][i];

            sibling.offsetX += offset;
            sibling.draw();
        }
    } else {
        for (var i = node.levelIndex; i > 0; i--) {
            var sibling = layers[node.level][i];
            sibling.offsetX += offset;
            sibling.draw();
        }
    }
}

function drawEdges() {

    edges.forEach(function(edge){
        if (edge.sourceNode.level + 1 == edge.targetNode.level && edge.sourceNode.type != "placeholder" && edge.targetNode.type != "placeholder") {
            var key = edge.sourceNode.level+"-"+(edge.sourceNode.level + 1);
            if (edgesInLayerGap[key] == null) {
                edgesInLayerGap[key] = [];
            }

            edgesInLayerGap[key].push(edge);
        }
    });

    for (var key in edgesInLayerGap) {
        var gap = edgesInLayerGap[key];

        gap.forEach(function(edge, index){
            if (index == 0) {
                edge.level = 0;
            } else {
                var overlap = false;
                var overlapLevel = 0;
                gap.forEach(function(secondEdge, secondIndex){
                    if (secondIndex >= index)
                        return;

                    var int1 = getPortXPositions(edge);
                    var int2 = getPortXPositions(secondEdge);

                    if (isIntervalOverlappingRight(int1, int2)) {
                        overlap = true;
                        if (secondEdge.level >= overlapLevel) {
                            overlapLevel = secondEdge.level + 1;
                        }
                    }

                    if (isIntervalOverlappingLeft(int1, int2)) {
                        overlap = true;
                        if (secondEdge.level <= overlapLevel) {
                            overlapLevel = secondEdge.level - 1;
                        }
                    }
                });

                if (overlap) {
                    edge.level = overlapLevel;
                } else {
                    edge.level = 0;
                }
            }
        });
    }

    edges.forEach(function(edge){
        if (edge.sourceNode.type != "placeholder" && edge.targetNode.type != "placeholder") {
            drawEdge(edge);
        }
    });
}

function getLayerHeight(layer) {
    var maxHeight = 0;
    layer.forEach(function(node, levelIndex){
        if (node.height > maxHeight)
            maxHeight = node.height;
    });

    return maxHeight;
}

function getLayerStartHeight(level) {
    var y = 0;
    if (level == 0) {
        y = startHeight;
    } else {
        for(var i = 0; i < level; i++) {
            y += layerHeight[i];
        }
        y += (level * levelSpace) + startHeight;
    }

    return y;
}

function computeLayerWidths() {
    layers.forEach(function(layer, level){
        var width = 0;
        layer.forEach(function(node, levelIndex){
            width += node.width;
        });

        width += (layer.length-1) * nodeSpace;
        layerWidth[level] = width;

        if (width > maxLayerWidth) {
            maxLayerWidth = width;
        }
    });
}

function drawEdge(edge) {
    var source = edge.sourceNode;
    var target = edge.targetNode;

    if (source.type == "placeholder" || target.type == "placeholder")
        return;

    var startX = source.x + source.width/2 + source.offsetX;
    var startY = source.y + source.height;

    var endX = target.x + target.width/2 + target.offsetX;
    var endY = target.y;

    var edgePortXValues = getPortXPositions(edge);

    var outgoingPortXOffset = edgePortXValues[0];
    var incomingPortXOffset = edgePortXValues[1];

    var segments = [[outgoingPortXOffset, startY]];

    var gapMiddle = ((layers[target.level][0].y + (layers[target.level - 1][0].y + layerHeight[target.level - 1])) / 2);

    var h = gapMiddle - startY + ((Math.floor(edge.sourceNode.children.length/2) - edge.sourcePort) * - 4);

    var yOffset = gapMiddle - startY;

    if (edge.level == null) {
        var minLevel = 1;
        var interval = getPortXPositions(edge);
        var direction = getIntervalDirection(interval);
        edge.targetNode.parents.forEach(function(parentEdge){
            var secondInterval = getPortXPositions(parentEdge);
            var secondDirection = getIntervalDirection(secondInterval);
            if (parentEdge.level != null && direction == secondDirection && parentEdge.level < minLevel) {
                minLevel = parentEdge.level;
            }
        });
        edge.level = minLevel - 1;
    }

    yOffset += (-5 * edge.level);

    segments.push([outgoingPortXOffset, startY  + yOffset]);
    segments.push([incomingPortXOffset, startY  + yOffset]);
    segments.push([incomingPortXOffset, endY - 1]);

    var path = arc({
        segments: segments,
        color: strokeColor,
        fillArrows: true,
    });


    //path.strokeColor = "red";

    path = roundPath(path, 2);
    lines.push(path);
}

/**
*    First entry outgoing port, second entry incoming port.
*/
function getPortXPositions(edge) {
    //FIXME: duplicate in drawEdge (refactor!!)
    var source = edge.sourceNode;
    var target = edge.targetNode;

    var startX = source.x + source.width/2 + source.offsetX;
    var startY = source.y + source.height;

    var endX = target.x + target.width/2 + target.offsetX;
    var endY = target.y;

    var outgoingEdgeCount = source.children.length - source.placeholderPaths.length;
    var incomingEdgeCount = target.parents.length;

    //count placeholder parents
    var placeHolderParentsCount = 0;
    target.parents.forEach(function(parentEdge){
        if (parentEdge.sourceNode.type == "placeholder")
            placeHolderParentsCount++;
    });

    incomingEdgeCount -= placeHolderParentsCount;

    var outgoingPortWidth = outgoingEdgeCount + ((outgoingEdgeCount-1) * outgoingEdgeSpace);
    //FIXME: not needed here...
    var outgoingPortXOffset =  startX - outgoingPortWidth/2 + (edge.sourcePort * (outgoingEdgeSpace + 1));

    var incomingPortWidth = incomingEdgeCount + ((incomingEdgeCount-1) * incomingEdgeSpace);
    //FIXME: not needed here...
    var incomingPortXOffset =  endX - incomingPortWidth/2 + (edge.targetPort * (incomingEdgeSpace + 1));

    return [outgoingPortXOffset, incomingPortXOffset];
}

function isIntervalOverlappingLeft(interval1, interval2) {
    var int1 = [Math.min(interval1[0], interval1[1]), Math.max(interval1[0], interval1[1])];
    var int2 = [Math.min(interval2[0], interval2[1]), Math.max(interval2[0], interval2[1])];

    // |--int1--|
    //    |--int2--|
    if (int2[0] >= int1[0] && int2[0] < int1[1] && int2[1] >= int1[1]) {
        return true;
    }

    return false;
}

function isIntervalOverlappingRight(interval1, interval2) {
    var int1 = [Math.min(interval1[0], interval1[1]), Math.max(interval1[0], interval1[1])];
    var int2 = [Math.min(interval2[0], interval2[1]), Math.max(interval2[0], interval2[1])];

/*
    // |----int1-----|
    //   |--int2--|
    if (int1[0] <= int2[0] && int2[1] <= int1[1]) {
        return true;
    }
*/


    //    |--int1--|
    // |--int2--|
    if (int2[0] <= int1[0] && int2[1] >= int1[0] && int2[1] <= int1[1]) {
        return true;
    }
/*
    //    |--int1--|
    // |-----int2-----|
    if (int2[0] <= int1[0] && int2[1] >= int1[0] && int2[1] >= int1[1]) {
        return true;
    }
*/
    return false;
}

/**
    True if right direction, false if left direction
*/
function getIntervalDirection(interval) {
    return interval[0] < interval[1];
}

function isOverlapping(line1, line2) {
    for (var i = 0; i < line1.length - 1; i++) {
        var segment1 = [line1[i], line1[i+1]];

        for (var j = 0; j < line2.length - 1; j++) {
            var segment2 = [line2[j], line2[j+1]];

            if (getLineIntersection(segment1, segment2) == 1)
                return true;
        }
    }
}

function getLineIntersection(segment1, segment2) {
    var p0 = segment1[0];
    var p1 = segment1[1];
    var p2 = segment2[0];
    var p3 = segment2[1];

    var s1_x = p1[0] - p0[0];
    var s1_y = p1[1] - p0[1];
    var s2_x = p3[0] - p2[0];
    var s2_y = p3[1] - p2[1];


    var s = (-s1_y * (p0[0] - p2[0]) + s1_x * (p0[1] - p2[1])) / (-s2_x * s1_y + s1_x * s2_y);
    var t = ( s2_x * (p0[1] - p2[1]) - s2_y * (p0[0] - p2[0])) / (-s2_x * s1_y + s1_x * s2_y);

    if (s >= 0 && s <= 1 && t >= 0 && t <= 1) {
        // Collision detected
        return 1;
    }

    return 0; // No collision
}

function smoothLines(path, radius) {
    var segments = path.segments.slice(0);

    path.segments = [];
    for(var i = 0, l = segments.length; i < l; i++) {
        var curPoint = segments[i].point;
        var nextPoint = segments[i + 1 == l ? 0 : i + 1].point;
        var prevPoint = segments[i - 1 < 0 ? segments.length - 1 : i - 1].point;
        var nextDelta = curPoint - nextPoint;
        var prevDelta = curPoint - prevPoint;
        nextDelta.length = radius;
        prevDelta.length = radius;
        path.add({
            point:curPoint - prevDelta,
            handleOut: prevDelta/2
        });
        path.add({
            point:curPoint - nextDelta,
            handleIn: nextDelta/2
        });
    }
    path.closed = true;
    return path;
}

function setupPlanCanvas() {
    if (planCanvas == null) {
        var canvasDomElement = $('#plan-canvas');
        var initialWidth = canvasDomElement.width();
        planCanvas = new paper.PaperScope().setup(document.getElementById('plan-canvas'));
        canvasDomElement.attr("width",initialWidth);


        var project = planCanvas.project;

        var tool = new paper.Tool();

        tool.distanceThreshold = 8;
        tool.mouseStartPos = new paper.Point();
        tool.zoomFactor = 1.5;

        //zoom view
        canvasDomElement.bind('mousewheel DOMMouseScroll MozMousePixelScroll', function(e){
            var delta = 0;
            var children = project.activeLayer.children;

            e.preventDefault();
            e = e || window.event;
            if (e.type == 'mousewheel') {       //this is for chrome/IE
                    delta = e.originalEvent.wheelDelta;
                }
                else if (e.type == 'DOMMouseScroll') {  //this is for FireFox
                    delta = e.originalEvent.detail*-1;  //FireFox reverses the scroll so we force to to re-reverse...
                }

            if ((delta > 0) && (paper.view.zoom < upperZoomLimit)) {
                //scroll up

                var point = new paper.Point(e.originalEvent.offsetX, e.originalEvent.offsetY);
                point = paper.view.viewToProject(point);
                var zoomCenter = point.subtract(paper.view.center);
                var moveFactor = tool.zoomFactor - 1.0;
                paper.view.zoom *= tool.zoomFactor;
                paper.view.center = paper.view.center.add(zoomCenter.multiply(moveFactor / tool.zoomFactor));
                tool.mode = '';

            } else if((delta < 0) && (paper.view.zoom>lowerZoomLimit)){ //scroll down
                var point = new paper.Point(e.originalEvent.offsetX, e.originalEvent.offsetY);
                point = paper.view.viewToProject(point);
                var zoomCenter = point.subtract(paper.view.center);
                var moveFactor = tool.zoomFactor - 1.0;
                paper.view.zoom /= tool.zoomFactor;
                paper.view.center = paper.view.center.subtract(zoomCenter.multiply(moveFactor))
            }
        });

        //pan view
        tool.onMouseDrag = function (event) {
            var canvasOffset = canvasDomElement.offset();
            var x = event.event.x - canvasOffset.left;
            var y = event.event.y - canvasOffset.top;

            if (event.tool._count == 1) {
               lastX = x;
               lastY = y;
               window.document.body.style.cursor = 'move';
               IsDrag = true;
            }

            var point = new paper.Point(lastX - x, lastY - y);

            point = point.multiply( 1 / paper.view.zoom);

            planCanvas.project.view.scrollBy(point);
            lastX = x;
            lastY = y;
        }

        //pan view
        tool.onMouseUp = function (event) {
            if (IsDrag == true) {
                // reset
                IsDrag = false;
                window.document.body.style.cursor = 'default';
            }
        }
    }
}

function initWordWrap() {
    planCanvas.PointText.prototype.wordwrap = function(text, maxChar){
        var lines = [],
            space = -1,
            times = 0;

        function cut(){
            for (var i = 0; i < text.length; i++){
                (text[i] == ' ') && (space = i);

                if(i >= maxChar){
                    (space == -1 || text[i] == ' ') && (space = i);

                    if(space>0)
                        lines.push(text.slice((text[0] == ' ' ? 1 : 0),space));

                    text = text.slice(text[0] == ' ' ? (space+1) : space);
                    space = -1;
                    break;
                }
            }
            check();
        }

        function check(){
            if (text.length <= maxChar){
                lines.push(text[0] == ' ' ? text.slice(1) : text);
                text='';
            }else if(text.length){
                cut();
            }
            return;
        }

        check();
        return this.content = lines.join('\n');
    }
}